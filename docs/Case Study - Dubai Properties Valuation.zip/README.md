    # Instructions
    # Environment setup
    # Data requirements
    # How to train the model
    # How to make predictions using the trained model
